import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { CartItem } from '../services/cart.service';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-cart-items',
  standalone: false,
  templateUrl: './cart-items.component.html',
  styleUrl: './cart-items.component.css'
})
export class CartItemsComponent implements OnInit, OnDestroy {

  cartItems$!: Observable<CartItem[]>;
  private cartSubscription?: Subscription;

  userId: number = 1;

  constructor(private cartService: CartService) { }

  ngOnInit(): void {
    this.loadCartItems();
  }

  ngOnDestroy(): void {
    if (this.cartSubscription) {
      this.cartSubscription.unsubscribe();
    }
  }

  loadCartItems() {
    this.cartItems$ = this.cartService.getCartItemsObservable();
    this.cartSubscription = this.cartService.getCartItems(this.userId).subscribe({
      error: (error) => {
        console.error('Error loading cart items:', error);
      }
    });
  }

  onQuantityChange(event: { id: number, quantity: number, cartItemId?: number, item: CartItem }) { // Added 'item: CartItem' to event
    if(event.cartItemId && event.item){ // Ensure item is also passed
      const newQuantity = event.quantity;
      const cartItemIdToUpdate = event.cartItemId;
      const currentCartItems = this.cartService.getCartItemsObservable(); // Get current cart items observable

      // **Immediate UI Update:**
      const updatedCartItemsValue = this.cartService['cartItems'].value || []; // Access .value on BehaviorSubject      const updatedItems = updatedCartItemsValue.map(item => {
      //   const updatedItems = updatedCartItemsValue.map((item: CartItem) => { // Explicitly type 'item' as CartItem          return { ...item, quantity: newQuantity }; // Update quantity in local array
      //   }
      //   return item;
      // });

      const updatedItems = updatedCartItemsValue.map((item : CartItem) =>{
        return item;
      });
      this.cartService['cartItems'].next(updatedItems); // **Directly update BehaviorSubject to trigger UI refresh**


      this.cartService.updateQuantity(this.userId, cartItemIdToUpdate, newQuantity).subscribe({
        next: (updatedItemFromBackend) => {
          console.log('Quantity updated successfully in backend', updatedItemFromBackend);
          // **Optionally, you can update more properties from backend response if needed**
          // For example, if backend calculates totalPrice and returns it in updatedItemFromBackend:
          // const finalUpdatedItems = updatedItemsValue.map(item =>
          //   item.cartItemId === cartItemIdToUpdate ? { ...item, ...updatedItemFromBackend } : item
          // );
          // this.cartService['cartItems'].next(finalUpdatedItems); // Update with backend data (optional)
        },
        error: (error) => {
          console.error('Error updating quantity in backend:', error);
          // **Optionally, revert UI change on backend error, or show error message**
          // Example of reverting UI change:
          // const revertedItems = updatedItemsValue.map(item => {
          //   if (item.cartItemId === cartItemIdToUpdate) {
          //     return { ...item, quantity: item.quantity }; // Revert to original quantity
          //   }
          //   return item;
          // });
          // this.cartService['cartItems'].next(revertedItems);
          // this.loadCartItems(); // Or reload entire cart if revert is complex
        }
      });
    } else {
      console.error('Cart Item ID or Item is missing for quantity update');
    }
  }


  onRemoveItem(cartItemId: number) {
    this.cartService.removeItem(this.userId, cartItemId).subscribe({
      next: () => {
        this.loadCartItems();
      },
      error: (error) => {
        console.error('Error removing item:', error);
        this.loadCartItems();
      }
    });
  }

  getTotal() {
    return this.cartService.getTotal();
  }

  emptyCart() {
    this.cartService.emptyCart(this.userId).subscribe({
      next: () => {
        this.loadCartItems();
      },
      error: (error) => {
        console.error('Error emptying cart:', error);
      }
    });
  }
}

//cart-items.component.ts

// import { Component, OnInit, OnDestroy } from '@angular/core'; // Import OnDestroy
// import { Observable, Subscription } from 'rxjs'; // Import Subscription
// import { CartItem } from '../services/cart.service';
// import { CartService } from '../services/cart.service';

// @Component({
//   selector: 'app-cart-items',
//   standalone: false,
//   templateUrl: './cart-items.component.html',
//   styleUrl: './cart-items.component.css'
// })
// export class CartItemsComponent implements OnInit, OnDestroy { // Implement OnDestroy

//   cartItems$!: Observable<CartItem[]>;
//   private cartSubscription?: Subscription; // Subscription to manage observable

//   userId: number = 1; // Hardcoded user ID for now - **IMPORTANT: Replace with dynamic user ID from auth context in real app**

//   constructor(private cartService: CartService) { }

//   ngOnInit(): void {
//     this.loadCartItems(); // Load cart items on component initialization
//   }

//   ngOnDestroy(): void { // Unsubscribe to prevent memory leaks
//     if (this.cartSubscription) {
//       this.cartSubscription.unsubscribe();
//     }
//   }

//   loadCartItems() {
//     this.cartItems$ = this.cartService.getCartItemsObservable(); // Get observable of cart items
//     this.cartSubscription = this.cartService.getCartItems(this.userId).subscribe({ // Fetch cart items from backend and subscribe
//       error: (error) => {
//         console.error('Error loading cart items:', error); // Basic error handling
//       }
//     });
//   }

//   onQuantityChange(event: { id: number, quantity: number, cartItemId?: number }) { // Added cartItemId to event
//     if(event.cartItemId){
//       this.cartService.updateQuantity(this.userId, event.cartItemId, event.quantity).subscribe({ // Call updateQuantity service method with userId and cartItemId
//         error: (error) => {
//           console.error('Error updating quantity:', error);
//           // Optionally reload cart items to reflect latest state from server if update fails partially
//           this.loadCartItems();
//         }
//       });
//     } else {
//       console.error('Cart Item ID is missing for quantity update');
//     }

//   }

//   onRemoveItem(cartItemId: number) { // Pass cartItemId
//     this.cartService.removeItem(this.userId, cartItemId).subscribe({ // Call removeItem service method with userId and cartItemId
//       error: (error) => {
//         console.error('Error removing item:', error);
//         this.loadCartItems(); // Optionally reload cart items on error
//       }
//     });
//   }

//   getTotal() {
//     return this.cartService.getTotal();
//   }

//   emptyCart() {
//     this.cartService.emptyCart(this.userId).subscribe({ // Call emptyCart service method with userId
//       next: () => {
//         // Cart emptied successfully, you might want to reload cart items or just update the observable to empty array in service
//         this.loadCartItems(); // Reload cart items to reflect empty cart
//       },
//       error: (error) => {
//         console.error('Error emptying cart:', error);
//         // Optionally handle error, maybe show a message
//       }
//     });
//   }
// }


