import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // Import HttpClient and HttpHeaders
import { map, tap } from 'rxjs/operators'; // Import tap for side effects

export interface CartItem { // Update CartItem interface to match backend DTO (CartItemDto)
  cartItemId?: number; // Backend generates ID, optional on frontend
  userId: number;      // Keep userId - needed for requests
  productId: number;
  quantity: number;
  productName?: string; // Optional as it's fetched from backend
  productPrice?: number; // Optional as it's fetched from backend
  productImage?: string; // Optional as it's fetched from backend
  totalPrice?: number;  // Optional, calculated by backend or frontend
}

export interface CartDto { // Define CartDto interface to match backend
  cartId?: number;
  userId: number;
  addedAt?: string; // Or LocalDateTime if you use a proper date parsing
  userName?: string;
  cartItems: CartItem[]; // Array of CartItem inside CartDto
}

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartItems = new BehaviorSubject<CartItem[]>([]); // Initialize with empty array
  private apiUrl = 'http://localhost:8090/api/cart'; // Base URL for Cart Microservice API

  constructor(private http: HttpClient) { } // Inject HttpClient

  getCartItems(userId: number): Observable<CartItem[]> {
    return this.http.get<any>(`${this.apiUrl}/${userId}`).pipe( // Response type is 'any' now for flexibility initially
        map((response: any) => { // Map the entire response
            if (response && response.data && response.data.cart && response.data.cart.length > 0) {
                return response.data.cart[0].cartItems || []; // Navigate to response.data.cart[0].cartItems
            } else {
                return [];
            }
        }),
        tap(items => {
            this.cartItems.next(items);
        })
    );
}

  updateQuantity(userId: number, cartItemId: number, quantity: number): Observable<CartItem> { // Pass userId and cartItemId
    return this.http.put<CartItem>(`${this.apiUrl}/${userId}/cart-items/${cartItemId}`, { quantity }).pipe( // Call PUT endpoint
      tap(updatedItem => {
        const currentItems = this.cartItems.value;
        const updatedItems = currentItems.map(item =>
          item.cartItemId === cartItemId ? { ...item, ...updatedItem } : item // Update item in BehaviorSubject
        );
        this.cartItems.next(updatedItems);
      })
    );
  }

  removeItem(userId: number, cartItemId: number): Observable<any> { // Pass userId and cartItemId
    return this.http.delete(`${this.apiUrl}/${userId}/cart-items/${cartItemId}`).pipe( // Call DELETE endpoint
      tap(() => {
        const currentItems = this.cartItems.value;
        const updatedItems = currentItems.filter(item => item.cartItemId !== cartItemId); // Remove item from BehaviorSubject
        this.cartItems.next(updatedItems);
      })
    );
  }

  emptyCart(userId: number): Observable<any> { // Pass userId
    return this.http.delete(`${this.apiUrl}/${userId}`).pipe( // Call DELETE endpoint to clear cart
      tap(() => {
        this.cartItems.next([]); // Clear BehaviorSubject
      })
    );
  }

  getTotal(): number { // Calculate total from BehaviorSubject value
    return this.cartItems.value.reduce(
      (total, item) => total + (item.productPrice || 0) * item.quantity, // Use optional chaining in case productPrice is undefined
      0
    );
  }

  getCartItemsObservable(): Observable<CartItem[]> { // Expose BehaviorSubject as Observable
    return this.cartItems.asObservable();
  }
}

//cart.service.ts

// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';

// export interface CartItem {
//   id: number;
//   name: string;
//   price: number;
//   quantity: number;
//   image: string;
// }

// @Injectable({
//   providedIn: 'root',
// })
// export class CartService {
//   private cartItems = new BehaviorSubject<CartItem[]>([
//     {
//       id: 1,
//       name: 'Wireless Headphones',
//       price: 99.99,
//       quantity: 1,
//       image: 'https://picsum.photos/200/200',
//     },
//     {
//       id: 2,
//       name: 'Smartphone',
//       price: 699.99,
//       quantity: 1,
//       image: 'https://picsum.photos/200/200',
//     },
//     {
//       id: 3,
//       name: 'Laptop',
//       price: 1299.99,
//       quantity: 1,
//       image: 'https://picsum.photos/200/200',
//     },
//   ]);

//   constructor() {}

//   getCartItems() {
//     return this.cartItems.asObservable();
//   }

//   updateQuantity(itemId: number, quantity: number) {
//     const currentItems = this.cartItems.value;
//     const updatedItems = currentItems
//       .map((item) =>
//         item.id === itemId ? { ...item, quantity: Math.max(0, quantity) } : item
//       )
//       .filter((item) => item.quantity > 0);
//     this.cartItems.next(updatedItems);
//   }

//   removeItem(itemId: number) {
//     const currentItems = this.cartItems.value;
//     const updatedItems = currentItems.filter((item) => item.id !== itemId);
//     this.cartItems.next(updatedItems);
//   }

//   getTotal() {
//     return this.cartItems.value.reduce(
//       (total, item) => total + item.price * item.quantity,
//       0
//     );
//   }

//   emptyCart() {
//     this.cartItems.next([]);
//   }
// }
