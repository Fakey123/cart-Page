import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotComponent } from './components/forgot/forgot.component';
import { SignupComponent } from './components/signup/signup.component';
import { LoginComponent } from './components/login/login.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ProductResultDisplayComponent } from './components/product-result-display/product-result-display.component';
import { ImageComponent } from './components/image/image.component';
import { UserDetailsComponent } from './components/user-details/user-details.component';
import { CartItemsComponent } from './components/cart-items/cart-items.component';


const routes: Routes = [
  {path:'signup', component:SignupComponent},
  {path:'login', component:LoginComponent},
  {path:'forgot', component:ForgotComponent},
  {path:'homepage',component:NavbarComponent},
  {path: 'search-results',component:ProductResultDisplayComponent},
  {path:'images',component:ImageComponent},
  {path:'userdetails',component:UserDetailsComponent},
  {path:'cartItems',component:CartItemsComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
