import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ForgotComponent } from './components/forgot/forgot.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { AuthInterceptor } from './interceptors/auth.service';
import { FilterComponent } from './components/filter/filter.component';
import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { SortComponent } from './components/sort/sort.component';
import { ProductResultDisplayComponent } from './components/product-result-display/product-result-display.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ImageComponent } from './components/image/image.component';
import { UserDetailsComponent } from './components/user-details/user-details.component';
import { CartItemsComponent } from './components/cart-items/cart-items.component';
import { CartComponent } from './components/cart/cart.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ForgotComponent,
    LoginComponent,
    SignupComponent,
    FilterComponent,
    SortComponent,
    ProductResultDisplayComponent,
    ImageComponent,
    UserDetailsComponent,
    CartItemsComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    HttpClientModule ,
    NgxSliderModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }