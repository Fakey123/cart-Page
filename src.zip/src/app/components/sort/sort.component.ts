import { Component, Output, EventEmitter } from '@angular/core';
import { SearchDataService } from '../../services/shared/search-data.service';
import { ProductResponseDTO } from '../../models/productfilterresponse';
import { FilterService } from '../../services/filter.service';
import { ProductDTO } from '../../models/productdto';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.css'],
  standalone: false
})
export class SortComponent {
  @Output() sortChanged = new EventEmitter<string>();
  isOpen = false;
  selectedSort = 'Relevance';
  sortOptions = [
    'Relevance',
    'Price: Low to High',
    'Price: High to Low',
    'Rating',
    'Popularity'
  ];

  constructor(private searchDataService: SearchDataService, private filterService: FilterService) {}

  toggleDropdown(): void {
    this.isOpen = !this.isOpen;
    console.log('Dropdown isOpen:', this.isOpen); // Debugging statement
  }

  handleSort(option: string): void {
    this.selectedSort = option;
    this.isOpen = false;
    this.sortChanged.emit(option);

    // Get the current search results
    const currentResults = this.searchDataService.getSearchResults();
    if (currentResults && currentResults.products) {
      let sortedProducts: ProductDTO[] = [...currentResults.products];

      // Sort the products based on the selected option
      switch (option) {
        case 'Price: Low to High':
          sortedProducts.sort((a, b) => a.newPrice - b.newPrice);
          console.log('Sorted by Price: Low to High', sortedProducts);
          break;
        case 'Price: High to Low':
          sortedProducts.sort((a, b) => b.newPrice - a.newPrice);
          console.log('Sorted by Price: High to Low', sortedProducts);
          break;
        case 'Rating':
          sortedProducts.sort((a, b) => b.rating - a.rating);
          console.log('Sorted by Rating', sortedProducts);
          break;
        case 'Popularity':
          sortedProducts.sort((a, b) => (b.popularity || '').localeCompare(a.popularity || ''));
          console.log('Sorted by Popularity', sortedProducts);
          break;
        default:
          // Implement relevance sorting if needed
          break;
      }

      // Update the search results with the sorted products
      const sortedResults: ProductResponseDTO = {
        ...currentResults,
        products: sortedProducts
      };
      this.searchDataService.setSearchResults(sortedResults);
    }
  }
}