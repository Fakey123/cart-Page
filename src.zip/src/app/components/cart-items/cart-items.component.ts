// cart-items.component.ts

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { CartService } from '../../services/cart.service';
import * as bootstrap from 'bootstrap';
import { CartItem } from '../../models/cartdtos';

@Component({
    selector: 'app-cart-items',
    standalone: false,
    templateUrl: './cart-items.component.html',
    styleUrl: './cart-items.component.css'
})
export class CartItemsComponent implements OnInit, OnDestroy {

    cartItems$!: Observable<CartItem[]>;
    private cartSubscription?: Subscription;
    userId: number= 3;

    private toast!: bootstrap.Toast;

    constructor(private cartService: CartService) { }

    ngOnInit(): void {
        // this.getUserIdFromLocalStorage();
        this.loadCartItems();
        this.initializeToast();
        
    }


    getUserIdFromLocalStorage(): void {
        // let userIdString = localStorage.getItem('userId');
        let userIdString = sessionStorage.getItem('userId');
    
        if (userIdString) {
          this.userId = Number(JSON.parse(userIdString));
          console.log("User ID:", this.userId);
        } else {
          console.log("No userId found in Session Storage");
        }
      }

    initializeToast() {
        const toastElement = document.querySelector('#liveToast') as HTMLElement;
        if (toastElement) {
            this.toast = new bootstrap.Toast(toastElement);
        }
    }

    
    

    showToast(message: string, title: string = 'Success') {
        if (this.toast) {
            const toastTitle = document.querySelector('.toast-title') as HTMLElement;
            const toastMessage = document.querySelector('.toast-message') as HTMLElement;
            if (toastTitle) toastTitle.textContent = title;
            if (toastMessage) toastMessage.textContent = message;
            this.toast.show();
        }
    }

    ngOnDestroy(): void {
        if (this.cartSubscription) {
            this.cartSubscription.unsubscribe();
        }
    }

    loadCartItems() {
        this.cartItems$ = this.cartService.getCartItemsObservable();
        this.cartSubscription = this.cartService.getCartItems(this.userId).subscribe({
            error: (error) => {
                console.error('Error loading cart items:', error);
            }
        });
    }

    onQuantityChange(event: { id: number, quantity: number, cartItemId?: number, item: CartItem }) {
    if (event.cartItemId && event.item) {
        const newQuantity = event.quantity;
        const cartItemIdToUpdate = event.cartItemId;

        const updatedCartItemsValue = this.cartService['cartItems'].value || [];

        const updatedItems = updatedCartItemsValue.map((item: CartItem) => {
            if (item.cartItemId === cartItemIdToUpdate) {
                const updatedTotalPrice = item.productPrice !== undefined ? item.productPrice * newQuantity : 0;
                return { ...item, quantity: newQuantity, totalPrice: updatedTotalPrice };
            } else {
                return item;
            }
        });
        this.cartService['cartItems'].next(updatedItems);

        this.cartService.updateQuantity(this.userId, cartItemIdToUpdate, newQuantity).subscribe({
            next: (updatedItemFromBackend) => {
                console.log('Quantity updated successfully in backend', updatedItemFromBackend);
                // No toast here for quantity change as it might be too frequent
            },
            error: (error) => {
                console.error('Error updating quantity in backend:', error);
            }
        });
    } else {
        console.error('Cart Item ID or Item is missing for quantity update');
    }
  }

    onRemoveItem(cartItemId: number | undefined) {
    if (!cartItemId) {
        console.error('Cart Item ID is missing for removal');
        return;
    }
    this.cartService.removeItem(this.userId, cartItemId).subscribe({
        next: () => {
            this.loadCartItems();
            this.showToast('Item removed from cart.', 'Success'); // Show toast on item removal
        },
        error: (error) => {
            console.error('Error removing item:', error);
            this.loadCartItems();
            this.showToast('Error removing item from cart.', 'Error'); // Show error toast
        }
    });
}

    getTotal() {
        return this.cartService.getTotal();
    }

      emptyCart() {
      if (confirm('Are you sure you want to empty your cart?')) { // Confirmation dialog
          this.cartService.emptyCart(this.userId).subscribe({
              next: () => {
                  this.loadCartItems();
                  this.showToast('Cart emptied successfully.', 'Success'); // Show toast after emptying cart
              },
              error: (error) => {
                  console.error('Error emptying cart:', error);
                  this.showToast('Error emptying cart.', 'Error'); // Show error toast
              }
          });
      }
  }

    // **Modify onCheckoutClicked() to handle full cart checkout**
    onCheckoutClicked(): void {
        const currentCartItems = this.cartService['cartItems'].value; // Get current cart items from BehaviorSubject

        if (!currentCartItems || currentCartItems.length === 0) {
            this.showToast('Your cart is empty. Add items to checkout.', 'Warning');
            return; // Do not proceed if cart is empty
        }

        this.cartService.placeOrder(this.userId, currentCartItems).subscribe({ // Call placeOrder service
            next: (response) => {
                if (response && response.success) {
                    this.showToast('Order placed successfully!', 'Success');
                    this.loadCartItems(); // Reload cart items to reflect empty cart
                } else {
                    this.showToast(response?.message || 'Could not place order.', 'Error'); // Show error message from backend or default
                }
            },
            error: (error) => {
                console.error('Error during checkout (full cart):', error);
                this.showToast('Error placing order. Please try again.', 'Error');
            }
        });
    }

    // **New function: onCheckoutClickedForItem() for per-item checkout**
    onCheckoutClickedForItem(item: CartItem): void {
        if (!item || !item.cartItemId) {
            console.error('Cart item is invalid for checkout.');
            this.showToast('Invalid item for checkout.', 'Error');
            return;
        }

        this.cartService.placeOrderByCartItem(this.userId, item.cartItemId).subscribe({ // Call placeOrderByCartItem service
            next: (response) => {
                if (response && response.success) {
                    this.showToast(`Order placed successfully for ${item.productName}!`, 'Success');
                    this.loadCartItems(); // Reload cart items to refresh the list
                } else {
                    this.showToast(response?.message || `Could not place order for ${item.productName}.`, 'Error'); // Show error message or default
                }
            },
            error: (error) => {
                console.error('Error during checkout (single item):', error);
                this.showToast(`Error placing order for ${item.productName}. Please try again.`, 'Error');
            }
        });
    }
}