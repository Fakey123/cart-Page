import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../../utils/custom-validators';
import { AuthserviceService } from '../../services/authservice.service';
import { authUser } from '../../models/authuser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: false
})
export class LoginComponent implements OnInit {
  registerForm: FormGroup;
  userData: any;
  errorMessage: any;
  token: string = "";
  loading: boolean = false;
  showToast: boolean = false;
  toastMessage: string = "";

  constructor(private _formBuilder: FormBuilder, private authService: AuthserviceService, private router: Router) {
    this.registerForm = this._formBuilder.group({
      email: ['', [Validators.required, CustomValidators.emailValidator()]],
      password: ['', [Validators.required, CustomValidators.passwordValidator()]]
    });
  }

  ngOnInit(): void { }

  onSubmit() {
    if (this.registerForm.valid) {
      this.loading = true;
      const user: authUser = {
        name: '',
        email: this.registerForm.value.email,
        phoneNumber: 0,
        password: this.registerForm.value.password
      };

      this.authService.login(user).subscribe({
        next: data => {
          console.log('Login successful', data);

          // localStorage.setItem('token', data.data.token);
          // localStorage.setItem('isAdmin', data.data.admin);
          // localStorage.setItem('userId', data.data.userId);
          sessionStorage.setItem('token', data.data.token);
          sessionStorage.setItem('isAdmin', data.data.admin);
          sessionStorage.setItem('userId', data.data.userId);
          this.toastMessage = 'Login successful';
          this.showToast = true;
          this.loading = false;
          this.router.navigate(['/homepage']);
          this.hideToastAfterDelay();
        },
        error: error => {
          this.errorMessage = error.message;
          console.log('Error in Login', error);
          this.toastMessage = 'Login failed';
          this.showToast = true;
          this.loading = false;
          this.hideToastAfterDelay();
        }
      });
    }
  }

  hideToastAfterDelay() {
    setTimeout(() => {
      this.showToast = false;
    }, 3000);
  }
}