import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../../utils/custom-validators';
import { AuthserviceService } from '../../services/authservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  standalone:false
})
export class SignupComponent implements OnInit {
  registerForm: FormGroup;

  constructor(private _formBuilder: FormBuilder, private authService: AuthserviceService) {
    this.registerForm = this._formBuilder.group({
      name: ['', [Validators.required, Validators.pattern('^[A-Za-z ]+$')]], // Only alphabets
      email: ['', [Validators.required, CustomValidators.emailValidator()]], // Valid email
      phone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]], // Exactly 10 digits
      password: ['', [Validators.required, CustomValidators.passwordValidator()]],
      confirmPassword: ['', Validators.required]
    }, {
      validators: CustomValidators.matchPasswords('password', 'confirmPassword')
    });
  }

  ngOnInit(): void {}

  onSubmit() {
    if (this.registerForm.valid) {
      const userData = {
        name: this.registerForm.value.name,
        email: this.registerForm.value.email,
        phoneNumber: this.registerForm.value.phone,
        password: this.registerForm.value.password
      };

      this.authService.signUp(userData).subscribe({
        next: (response) => {
          alert('Signup Successful');
          console.log('Response:', response);
        },
        error: (error) => {
          alert('Signup Failed');
          console.error('Error:', error);
        }
      });
    }
  }
}