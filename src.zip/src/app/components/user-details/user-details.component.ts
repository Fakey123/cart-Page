import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as bootstrap from 'bootstrap'; 
import { NavbarService } from '../../services/navbar.service';
import { UserDetailsService } from '../../services/user-details.service';
import { Address } from '../../models/user';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  standalone: false,
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  user: any = {};
  address: any = {};
  preference: any = {};
  isEditing = false;
  userForm: FormGroup;
  originalUser: any;
  originalAddress: any;
  userId: number;
  errorMessage: string;

  private userApiUrl = 'http://localhost:8765/api/user';
  private addressApiUrl = 'http://localhost:8765/user/addresses';
  private preferenceApiUrl = 'http://localhost:8765/user/preferences';

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private fb: FormBuilder,
    private navService: NavbarService,
    private userService: UserDetailsService
  ) {
    this.userForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern('^[A-Za-z ]+$')]],
      email: ['', [Validators.required, Validators.pattern('^[A-Za-z]+@[A-Za-z]+\.com$')]],
      phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      role: [{ value: '', disabled: true }],
      street: ['', [Validators.required, Validators.pattern('^[A-Za-z0-9 ]+$')]],
      city: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]],
      state: ['', [Validators.required, Validators.pattern('^[A-Za-z ]+$')]],
      postalCode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]],
      country: ['', [Validators.required, Validators.pattern('^[A-Za-z]+$')]]
    });
  }

  getUserIdFromLocalStorage(): void {
    let userIdString = sessionStorage.getItem('userId');
    console.log("User ID ---------------", userIdString);

    if (userIdString) {
      this.userId = Number(JSON.parse(userIdString));
      console.log("User ID:", this.userId);
    } else {
      console.log("No userId found in Session Storage");
    }
  }

  ngOnInit(): void {
    this.getUserIdFromLocalStorage();
    this.loadUserDetails();
    this.loadAddressDetails();
  }
  
  loadUserDetails(): void {
    this.navService.getUserById(this.userId).subscribe({
      next: data => {
        console.log("User data fetched:", data);
        this.user = data;
        this.checkAndUpdateForm();
      },
      error: error => {
        this.errorMessage = error.message;
        console.log("Error in fetching the User Data", error);
      },
      complete: () => {
        console.log("User data fetch operation completed successfully");
      }
    });
  }
  
  loadAddressDetails(): void {
    this.userService.getUserAddress(this.userId).subscribe({
      next: (data: Address) => {
        console.log('Address data fetched:', data);
        this.address = data;
        this.originalAddress = { ...data };
        console.log(this.originalAddress);
        this.checkAndUpdateForm();
      },
      error: (err) => {
        console.error('Error loading address', err);
        this.errorMessage = 'Error loading address';
      }
    });
  }
  
  checkAndUpdateForm(): void {
    console.log("Checking if form can be updated...");
    if (this.user && this.address) {
      console.log("Updating form with user and address data");
      this.updateForm();
    } else {
      console.log("User or address data is missing");
    }
  }
  
  updateForm(): void {
    if (this.user && this.address) {
      this.userForm.patchValue({
        name: this.user.name,
        email: this.user.email,
        phoneNumber: this.user.phoneNumber,
        role: this.user.role,
        street: this.address.street,
        city: this.address.city,
        state: this.address.state,
        postalCode: this.address.postalCode,
        country: this.address.country
      });
      console.log("Form updated with user and address data");
    } else {
      console.log('User or address data is missing');
    }
  }
  toggleEdit(): void {
    this.isEditing = !this.isEditing;
    if (!this.isEditing) {
      this.cancelEdit();
    }
  }

  saveUser(): void {
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      return;
    }

    const updatedUser = {
      ...this.user,
      name: this.userForm.value.name,
      email: this.userForm.value.email,
      phoneNumber: this.userForm.value.phoneNumber
    };

    const updatedAddress = {
      ...this.address,
      street: this.userForm.value.street,
      city: this.userForm.value.city,
      state: this.userForm.value.state,
      postalCode: this.userForm.value.postalCode,
      country: this.userForm.value.country
    };

    this.http.put(`${this.userApiUrl}/profile`, updatedUser).subscribe({
      next: (data: any) => {
        this.user = data;
        this.originalUser = { ...data };
        this.http.put(`${this.addressApiUrl}/${this.address.addressId}`, updatedAddress).subscribe({
          next: (addressData: any) => {
            this.address = addressData;
            this.originalAddress = { ...addressData };
            this.isEditing = false;
            const modal = new bootstrap.Modal(document.getElementById('successModal')!);
            modal.show();
          },
          error: (err) => console.error('Error updating address', err)
        });
      },
      error: (err) => console.error('Error updating user', err)
    });
  }

  cancelEdit(): void {
    this.userForm.patchValue({
      name: this.originalUser.name,
      email: this.originalUser.email,
      phoneNumber: this.originalUser.phoneNumber,
      role: this.originalUser.role,
      street: this.originalAddress.street,
      city: this.originalAddress.city,
      state: this.originalAddress.state,
      postalCode: this.originalAddress.postalCode,
      country: this.originalAddress.country
    });
    this.isEditing = false;
  }

  getAvatarUrl(): string {
    const gender = this.preference.gender?.toLowerCase() === 'female' ? 'female' : 'male';
    return `https://api.dicebear.com/9.x/avataaars/svg?seed=${this.user.name}&gender=${gender}`;
  }

  get f() { return this.userForm.controls; }
}