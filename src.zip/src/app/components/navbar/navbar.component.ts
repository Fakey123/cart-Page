import { Component, EventEmitter, HostListener, OnInit, Output } from '@angular/core';
import { NavbarService } from '../../services/navbar.service';
import { User } from '../../models/user';
import { SearchService } from '../../services/search.service';
import { SearchSuggestion } from '../../models/searchsuggestion';
import { SearchHistoryResponse, SearchHistoryItem } from '../../models/searchhistoryresponse';
import { ApiResponse } from '../../models/apiresponse';
import { AuthserviceService } from '../../services/authservice.service';
import { LoginComponent } from '../login/login.component';
import { Router } from '@angular/router';
import { FilterComponent } from '../filter/filter.component';
import { ProductResponseDTO } from '../../models/productfilterresponse';
import { SearchDataService } from '../../services/shared/search-data.service';
import { debounceTime } from 'rxjs';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  standalone: false ,
})
export class NavbarComponent implements OnInit {
  userId: number;
  searchResults:ProductResponseDTO;
  @Output() searchQueryChange = new EventEmitter<string>();
  typedquery:string ='prod';
  isLoggedIn: boolean = false;
  userData: User;
  searchControl: FormControl = new FormControl();
  currentUserIdResponse:ApiResponse;
  errorMessage: string;
  greeting: string;
  cartCount = 4;
  searchQuery: string = '';
  suggestions: { name: string, category: string }[] = [];
  allProducts: { name: string, category: string }[] = [];
  selectedIndex: number = -1;
  showSuggestions: boolean = false;
  placeholderText: string = 'Search for products...';
  initials: string;

  searchSuggestionData: SearchSuggestion;
  searchHistory: SearchHistoryItem[] = [];

  constructor(private navService: NavbarService, private searchService: SearchService, private authservice:AuthserviceService,private router:Router,private searchDataService: SearchDataService,) {

  }

  getGreeting() {
    const hour = new Date().getHours();
    let greeting;

    if (hour < 12) {
        greeting = 'Good Morning';
    } else if (hour < 17) {
        greeting = 'Good Afternoon';
    } else {
        greeting = 'Good Evening';
    }
    return greeting;
  }

  ngOnInit(): void {
    this.getUserIdFromLocalStorage();
  
    this.greeting = this.getGreeting();
    this.navService.getUserById(this.userId).subscribe({
      next: data => {
        this.userData = data;
        this.initials = this.userData.name
          .split(' ')
          .filter((_, index, array) => index === 0 || index === array.length - 1)
          .map(word => word[0])
          .join('')
          .toUpperCase();
        this.isLoggedIn = true; 
      },
      error: error => {
        this.errorMessage = error.message;
        console.log("Error in fetching the User Data");
      },
      complete: () => {
        console.log("Operation Completed Successfully");
      }
    });

    this.searchControl.valueChanges.pipe(
      debounceTime(300)
    ).subscribe(value => {
      this.searchQueryChange.emit(value);
    });
  
    // Fetch search history

    this.searchControl.valueChanges.pipe(
      debounceTime(300) // Adjust the debounce time as needed
    ).subscribe(value => {
      if (value) {
        this.fetchUserSearchHistory();
      }
    });
   
  }

  fetchUserSearchHistory(): void {
    this.searchService.getUserSearchHistory(this.userId).subscribe({
      next: (data: SearchHistoryResponse) => {
        this.searchHistory = data.history;
        console.log(data);
      },
      error: error => {
        this.errorMessage = error.message;
        console.log("Error in fetching the Suggestion");
      },
      complete: () => {
        console.log("Operation Completed Successfully");
      }
    });
  }

  profileDropdownVisible = false;
  hideDropdownTimeout: any;

  showProfileDropdown() {
    clearTimeout(this.hideDropdownTimeout);
    this.profileDropdownVisible = true;
  }

  hideProfileDropdown() {
    this.hideDropdownTimeout = setTimeout(() => {
      this.profileDropdownVisible = false;
    }, 100);
  }

  getUserIdFromLocalStorage(): void {
    // let userIdString = localStorage.getItem('userId');
    let userIdString = sessionStorage.getItem('userId');

    if (userIdString) {
      this.userId = Number(JSON.parse(userIdString));
      console.log("User ID:", this.userId);
    } else {
      console.log("No userId found in Session Storage");
    }
  }

  handleLogout(): void {
    this.authservice.logoutUser().subscribe({
      next: (response: ApiResponse) => {
        console.log('Logout successful', response);
        // localStorage.clear(); 
        sessionStorage.clear(); 
        this.isLoggedIn = false;
        this.router.navigate(['/login']);
      },
      error: error => {
        console.error('Logout failed', error);
      },
      complete: () => {
        console.log('Logout operation completed successfully');
      }
    });
  }
  updateSuggestions() {
    const suggestions: { name: string, category: string }[] = [];

    if (this.searchQuery.trim().length >= 3) { // Check if the search query has at least 3 characters
      // Fetch search suggestions from the service
      this.searchService.getSearchSuggestionsFromProductsPresentAvailable(this.searchQuery).subscribe({
        next: (data: SearchSuggestion) => {
          this.searchSuggestionData = data;
          this.allProducts = data.data.map(item => ({ name: item.productName, category: item.category }));

          // Add matching items from search history first 
          const matchingHistory = this.searchHistory.map(item => ({ name: item.query, category: '' })).filter(query =>
            query.name.toLowerCase().includes(this.searchQuery.toLowerCase())
          );
          suggestions.push(...matchingHistory);

          // Then add matching products that aren't in history
          const matchingProducts = this.allProducts.filter(product =>
            product.name.toLowerCase().includes(this.searchQuery.toLowerCase()) &&
            !suggestions.some(suggestion => suggestion.name === product.name)
          );
          suggestions.push(...matchingProducts);

          this.suggestions = suggestions;
          this.selectedIndex = this.suggestions.length > 0 ? 0 : -1;
          this.showSuggestions = this.suggestions.length > 0;

          // Set first suggestion as placeholder if available
          if (this.suggestions.length > 0) {
            this.placeholderText = this.suggestions[0].name;
          } else {
            this.placeholderText = 'Search for products...';
          }
        },
        error: error => {
          this.errorMessage = error.message;
          console.log("Error in fetching the Suggestion");
        },
        complete: () => {
          console.log("Operation Completed Successfully");
        }
      });
    } else {
      // Show recent history when search is empty or less than 3 characters
      suggestions.push(...this.searchHistory.map(item => ({ name: item.query, category: '' })));
      this.suggestions = suggestions;
      this.selectedIndex = this.suggestions.length > 0 ? 0 : -1;
      this.showSuggestions = this.suggestions.length > 0;

      // Set first suggestion as placeholder if available
      if (this.suggestions.length > 0) {
        this.placeholderText = this.suggestions[0].name;
      } else {
        this.placeholderText = 'Search for products...';
      }
    }
  }

  deleteHistoryItem(event: Event, item: string) {
    event.stopPropagation();
    const historyItem = this.searchHistory.find(historyItem => historyItem.query === item);
    if (historyItem) {
      this.searchService.deleteUserSearchHistoryBySearchId(this.userId, historyItem.searchId).subscribe({
        next: (data: ApiResponse) => {
          console.log('Search history deleted successfully:', data);
          if (data.status === 'success') {
            this.searchHistory = this.searchHistory.filter(historyItem => historyItem.query !== item);
            this.updateSuggestions();
          }
        },
        error: error => {
          this.errorMessage = error.message;
          console.log("Error in deleting the search history");
        }
      });
    }
  }

  highlightMatch(product: string): string {
    if (!this.searchQuery.trim()) return product;
    const regex = new RegExp(`(${this.searchQuery})`, 'gi');
    return product.replace(regex, '<strong>$1</strong>');
  }

  selectSuggestion(suggestion: string) {
    this.searchQuery = suggestion;
    this.suggestions = [];
    this.selectedIndex = -1;
    this.showSuggestions = false;
    this.placeholderText = 'Search for products...';
    this.performSearch();
  }
  onKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter' && this.selectedIndex !== -1) {
      this.selectSuggestion(this.suggestions[this.selectedIndex].name);
    } else if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (this.selectedIndex < this.suggestions.length - 1) {
        this.selectedIndex++;
      }
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (this.selectedIndex > 0) {
        this.selectedIndex--;
      }
    }
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: Event) {
    if (!(event.target as HTMLElement).closest('.search-box')) {
      this.showSuggestions = false;
    }
  }

  performSearch() {
    console.log('Searching for:', this.searchQuery);

    this.searchService.getSearchResults(this.searchQuery).subscribe({
      next: (data: ProductResponseDTO) => {
        console.log("Fetching the Search Results");
        console.log(data);
        // Store search results in the shared service and emit the event
        this.searchDataService.setSearchResults(data);
        // Navigate to the product result display component
        this.router.navigate(['/search-results'], { queryParams: { query: this.searchQuery } });
      },
      error: error => {
        this.errorMessage = error.message;
        console.log("Error in fetching the Search Results");
      },
      complete: () => {
        console.log("Search Results fetched Successfully");
      }
    });

    // Check if the search query is already in the search history
    const existingSearch = this.searchHistory.find(item => item.query === this.searchQuery);
    const currentDate = new Date().toISOString();
    if (existingSearch) {
      // Increase the search count if the query is already present
      existingSearch.searchCount += 1;
      existingSearch.lastSearched = currentDate;
      this.searchService.addUserSearchHistory(this.userId,existingSearch).subscribe({
        next: (data: SearchHistoryResponse) => {
          console.log('Search count updated successfully:', data);
        },
        error: (error) => {
          console.error('Error updating search count:', error);
        }
      });
    } else {
      const newSearch: SearchHistoryItem = {
        searchId: this.searchHistory.length + 1,
        userId: this.userId,
        query: this.searchQuery,
        searchCount: 1,
        lastSearched: currentDate
      };

      this.searchService.addUserSearchHistory(this.userId,newSearch).subscribe({
        next: (data: SearchHistoryResponse) => {
          console.log('Search history added successfully:', data);
          this.searchHistory.push(newSearch); // Update local search history
        },
        error: (error) => {
          console.error('Error adding search history:', error);
        }
      });
    }
  }
  isHistoryItem(suggestion: string): boolean {
    return this.searchHistory.some(item => item.query === suggestion);
  }
}
