// import { ChangeDetectorRef, Component, ViewChild, ViewEncapsulation } from '@angular/core';
// import { ProductDTO } from '../../models/productdto';
// import { ProductResponseDTO } from '../../models/productfilterresponse';
// import { SearchDataService } from '../../services/shared/search-data.service';
// import { MatPaginator, PageEvent } from '@angular/material/paginator';
// import { NavbarComponent } from '../navbar/navbar.component';

// @Component({
//   selector: 'app-product-result-display',
//   standalone: false,
//   templateUrl: './product-result-display.component.html',
//   styleUrl: './product-result-display.component.css',
//   encapsulation: ViewEncapsulation.None
// })
// export class ProductResultDisplayComponent {
//   searchQuery: string;
//   @ViewChild(NavbarComponent) navbarComponent: NavbarComponent;
//   products: ProductDTO[] = [];
//   paginatedProducts: ProductDTO[] = [];
//   pageSize = 10;
//   currentPage = 0;
//   totalSize = 0;

//   @ViewChild(MatPaginator) paginator: MatPaginator;

//   constructor(private searchDataService: SearchDataService) { }

//   handleSearchQueryChange(query: string) {
//     this.searchQuery = query;
//   }

//   ngOnInit(): void {
//     this.updateProducts();
//     this.searchDataService.searchResultsChanged.subscribe((searchResults: ProductResponseDTO) => {
//       this.updateProducts();
//     });
//   }

//   updateProducts(): void {
//     const searchResults: ProductResponseDTO = this.searchDataService.getSearchResults();
//     if (searchResults && searchResults.products) {
//       this.products = searchResults.products;
//       this.totalSize = this.products.length;
//       this.paginateProducts();
//     } else {
//       console.log('No search results available.');
//     }
//   }

//   paginateProducts(): void {
//     const startIndex = this.currentPage * this.pageSize;
//     const endIndex = startIndex + this.pageSize;
//     console.log(`PageSize: ${this.pageSize}, CurrentPage: ${this.currentPage}, StartIndex: ${startIndex}, EndIndex: ${endIndex}`);
//     this.paginatedProducts = this.products.slice(startIndex, endIndex);
//   }

//   onPageChange(event: PageEvent): void {
//     this.pageSize = event.pageSize;
//     this.currentPage = event.pageIndex;
//     this.paginateProducts();
//   }
// }


import { ChangeDetectorRef, Component, ViewChild, ViewEncapsulation, OnInit } from '@angular/core';
import { ProductDTO } from '../../models/productdto';
import { ProductResponseDTO } from '../../models/productfilterresponse';
import { SearchDataService } from '../../services/shared/search-data.service';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { NavbarComponent } from '../navbar/navbar.component';
import { ProductsService } from '../../services/products.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-product-result-display',
  standalone: false,
  templateUrl: './product-result-display.component.html',
  styleUrls: ['./product-result-display.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ProductResultDisplayComponent implements OnInit {
  searchQuery: string;
  @ViewChild(NavbarComponent) navbarComponent: NavbarComponent;
  products: ProductDTO[] = [];
  paginatedProducts: ProductDTO[] = [];
  pageSize = 10;
  currentPage = 0;
  totalSize = 0;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private searchDataService: SearchDataService,
    private imageService: ProductsService,
    private sanitizer: DomSanitizer
  ) { }

  handleSearchQueryChange(query: string) {
    this.searchQuery = query;
  }

  ngOnInit(): void {
    this.updateProducts();
    this.searchDataService.searchResultsChanged.subscribe((searchResults: ProductResponseDTO) => {
      this.updateProducts();
    });
  }

  updateProducts(): void {
    const searchResults: ProductResponseDTO = this.searchDataService.getSearchResults();
    if (searchResults && searchResults.products) {
      this.products = searchResults.products;
      this.totalSize = this.products.length;
      this.paginateProducts();
    } else {
      console.log('No search results available.');
    }
  }

  paginateProducts(): void {
    const startIndex = this.currentPage * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    console.log(`PageSize: ${this.pageSize}, CurrentPage: ${this.currentPage}, StartIndex: ${startIndex}, EndIndex: ${endIndex}`);
    this.paginatedProducts = this.products.slice(startIndex, endIndex);
    this.paginatedProducts.forEach(product => {
      this.loadImage(product, 'image1');
      this.loadImage(product, 'image2');
    });
  }

  loadImage(product: ProductDTO, imageType: 'image1' | 'image2'): void {
    this.imageService.getImage(6, 'image2').subscribe(
      (blob) => {
        const objectURL = URL.createObjectURL(blob);
        product[imageType] = this.sanitizer.bypassSecurityTrustUrl(objectURL) as SafeUrl;
      },
      (error) => {
        console.error(`Error fetching ${imageType} for product ${product.productId}`, error);
      }
    );
  }

  onPageChange(event: PageEvent): void {
    this.pageSize = event.pageSize;
    this.currentPage = event.pageIndex;
    this.paginateProducts();
  }
}