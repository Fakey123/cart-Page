import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductResultDisplayComponent } from './product-result-display.component';

describe('ProductResultDisplayComponent', () => {
  let component: ProductResultDisplayComponent;
  let fixture: ComponentFixture<ProductResultDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProductResultDisplayComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductResultDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
