import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-image',
  standalone: false,
  templateUrl: './image.component.html',
  styleUrl: './image.component.css'
})
export class ImageComponent implements OnInit {
  imageUrl: SafeUrl | null = null;

  constructor( private sanitizer: DomSanitizer,private productService:ProductsService) {}

  ngOnInit(): void {
    const id = 7; // Replace with actual ID
    const imageType = 'image2'; // Replace with actual image type

    this.productService.getImage(id, imageType).subscribe(
      (blob) => {
        const objectURL = URL.createObjectURL(blob);
        this.imageUrl = this.sanitizer.bypassSecurityTrustUrl(objectURL);
      },
      (error) => {
        console.error('Error fetching image', error);
      }
    );
  }
}