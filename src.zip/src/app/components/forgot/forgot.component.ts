import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../../utils/custom-validators';
import { Router } from '@angular/router';

import { AuthserviceService } from '../../services/authservice.service';
import { ForgotPasswordDTO } from '../../models/forgot-password.dto';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css'],
  standalone: false
})
export class ForgotComponent {
  forgotForm: FormGroup;
  otpSent: boolean = false;
  otpVerified: boolean = false;
  passwordDidNotMatch: boolean = false;

  constructor(private _formBuilder: FormBuilder, private authService: AuthserviceService, private router: Router) {
    this.forgotForm = this._formBuilder.group({
      email: ['', [Validators.required, CustomValidators.emailValidator()]],
      otp: ['', Validators.required],
      newpassword: ['', [Validators.required, CustomValidators.passwordValidator()]],
      confirmpassword: ['', [Validators.required, CustomValidators.passwordValidator()]]
    });
  }

  generateOtp() {
    const email = this.forgotForm.value.email;
    const dto: ForgotPasswordDTO = { email };
    this.authService.generateOtp(dto).subscribe(
      (response: any) => {
        if (response.status === 'success') {
          alert(response.message);
          this.otpSent = true;
        }
      },
      (error) => {
        alert('Error sending OTP');
      }
    );
  }

  verifyOtp() {
    const email = this.forgotForm.value.email;
    const otp = this.forgotForm.value.otp;
    const dto: ForgotPasswordDTO = { email, otp };
    this.authService.verifyOtp(dto).subscribe(
      (response: any) => {
        if (response.status === 'success' && response.data) {
          alert('OTP verified successfully');
          this.otpVerified = true;
        } else {
          alert('Invalid OTP');
        }
      },
      (error) => {
        alert('Error verifying OTP');
      }
    );
  }

  onSubmit() {
    if (this.forgotForm.value.newpassword === this.forgotForm.value.confirmpassword) {
      const email = this.forgotForm.value.email;
      const newPassword = this.forgotForm.value.newpassword;
      const dto = { email, newPassword }; // Ensure the field name matches the backend DTO
      this.authService.resetPassword(dto).subscribe(
        (response: any) => {
          if (response.status === 'success') {
            alert('Password reset successfully');
            this.router.navigate(['/login']);
          }
        },
        (error) => {
          if (error.status === 400) {
            alert('Bad Request: Please check the input data.');
          } else {
            alert('Error resetting password');
          }
        }
      );
    } else {
      this.passwordDidNotMatch = true;
    }
  }
}