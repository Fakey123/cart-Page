import { Component, Output, EventEmitter, OnInit, Input, SimpleChanges } from '@angular/core';
import { Options } from '@angular-slider/ngx-slider';
import { FilterService } from '../../services/filter.service';
import { SearchDataService } from '../../services/shared/search-data.service';
import { ProductResponseDTO } from '../../models/productfilterresponse';
import { ProductsService } from '../../services/products.service';
import { Category } from '../../models/categorydto';
import { Brand } from '../../models/brand.model';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css'],
  standalone: false
})
export class FilterComponent implements OnInit {
  @Input() searchQuery: string;
  @Output() filtersApplied = new EventEmitter<any>();
  isSidebarOpen = true;
  fetchedCategories: Category[] = []; 
  errorMessage: string;
  allBrands:Brand[] = [];
  genders: string[] = ['Male', 'Female', 'Unisex'];
  selectedGender: string | null = null;
  selectedCategory: number | null = null;
  colors: { name: string, code: string }[] = [
    { name: 'Red', code: '#FF0000' },
    { name: 'Blue', code: '#0000FF' },
    { name: 'Green', code: '#00FF00' },
    { name: 'Yellow', code: '#FFFF00' },
    { name: 'Black', code: '#000000' },
    { name: 'White', code: '#FFFFFF' },
  ];
  priceValue: number = 0;
  highValue: number = 1000;
  priceOptions: Options = {
    floor: 0,
    ceil: 1000,
    step: 10,
    showTicks: true,
    showTicksValues: true,
    tickStep: 200,
    getSelectionBarColor: (): string => '#ffc107',
    getPointerColor: (): string => '#ff9800'
  };
  ratingRange = { min: 1, max: 5 };
  discountRange = { min: 0, max: 100 };
  selectedBrand: string | null = null;
  selectedColor: string | null = null;

  constructor(
    private filterService: FilterService,
    private searchDataService: SearchDataService,
    private productService: ProductsService
  ) {}


  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['searchQuery']) {
      console.log('Search query changed:', this.searchQuery);
    }
  }

  ngOnInit(): void {
    this.productService.getAllCategories().subscribe({
      next: (data: Category[]) => { 
        console.log("Fetching all Categories");
        console.log(data);
        this.fetchedCategories = data;
      },
      error: (error) => {
        this.errorMessage = error.message;
        console.log("Error in fetching all Categories");
      },
      complete: () => {
        console.log("Successfully fetched all Categories");
      }
    });

    this.productService.getAllBrands().subscribe({
      next: (data: Brand[]) => { 
        console.log("Fetching all Categories");
        console.log(data);
        this.allBrands = data;
      },
      error: (error) => {
        this.errorMessage = error.message;
        console.log("Error in fetching the brands");
      },
      complete: () => {
        console.log("Successfully fetched all brands");
      }
    });
  }

  toggleSidebar(): void {
    this.isSidebarOpen = !this.isSidebarOpen;

    // Handle backdrop
    if (this.isSidebarOpen) {
      document.body.classList.add('overflow-hidden');
    } else {
      document.body.classList.remove('overflow-hidden');
      // Ensure backdrop is removed
      const backdrop = document.querySelector('.offcanvas-backdrop');
      if (backdrop) {
        backdrop.remove();
      }
    }
  }

  applyFilters(): void {
    const filters = {
      gender: this.selectedGender,
      category: this.selectedCategory,
      brand: this.selectedBrand,
      color: this.selectedColor,
      priceRange: { min: this.priceValue, max: this.highValue },
      ratingRange: this.ratingRange,
      discountRange: this.discountRange, 
    };
    this.filtersApplied.emit(filters);
  
    console.log('Applying filters:', filters);
    console.log("Search Query ------------",this.searchQuery)
  
    const category = this.selectedCategory ?? 2;
  
    this.filterService.getFilteredProducts(
      '', 
      category,
      this.priceValue,
      this.highValue,
      this.ratingRange.min,
      this.selectedBrand ? this.selectedBrand.replace(/\s+/g, '').toLowerCase() : undefined, // Remove spaces and convert to lowercase
      this.selectedColor || undefined,
      this.discountRange.min
    ).subscribe((response: ProductResponseDTO) => {
      console.log('Filtered products response:', response);
      this.searchDataService.setSearchResults(response);
    });
  }

  resetFilters(): void {
    this.selectedGender = null;
    this.selectedCategory = null;
    this.selectedBrand = null;
    this.selectedColor = null;
    this.priceValue = 0;
    this.highValue = 1000;
    this.ratingRange = { min: 1, max: 5 };
    this.discountRange = { min: 0, max: 100 }; // Reset discount range
    this.applyFilters();
  }
}