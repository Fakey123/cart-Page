export interface User {
  userId:number,
  name:string,
  email:string,
  phoneNumber:string,
  // passwordHash:string,
  role:string  
}


export interface Address {
  addressId: number;
  userId: number;
  street: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}