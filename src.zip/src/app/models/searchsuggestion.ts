import { Item } from "./Item";

export interface SearchSuggestion {
  message: string;
  status: string;
  data: Item[];
}