import { ProductDTO } from "./productdto";

export interface ProductResponseDTO {
    products: ProductDTO[];
    pagination: PaginationDTO;
  }

  export interface PaginationDTO {
    totalPages: number;
    currentPage: number;
  }


