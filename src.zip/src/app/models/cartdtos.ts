export interface CartItem { // Update CartItem interface to match backend DTO (CartItemDto)
    cartItemId?: number; // Backend generates ID, optional on frontend
    userId: number;      // Keep userId - needed for requests
    productId: number;
    quantity: number;
    productName?: string; // Optional as it's fetched from backend
    productPrice?: number; // Optional as it's fetched from backend
    productImage?: string; // Optional as it's fetched from backend
    totalPrice?: number;  // Optional, calculated by backend or frontend
  }
  
  export interface CartDto { // Define CartDto interface to match backend
    cartId?: number;
    userId: number;
    addedAt?: string; // Or LocalDateTime if you use a proper date parsing
    userName?: string;
    cartItems: CartItem[]; // Array of CartItem inside CartDto
  }
  