export interface Item {
    productId: number;
    category: string;
    productName: string;
  }