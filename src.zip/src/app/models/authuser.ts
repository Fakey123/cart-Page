export interface authUser {
    name:string;
    email:string;
    phoneNumber:number;
    password:string;
    
}
