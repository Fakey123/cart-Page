export interface SearchHistoryItem {
    searchId: number;
    userId: number;
    query: string;
    searchCount: number;
    lastSearched: string;
  }
  
  export interface SearchHistoryResponse {
    history: SearchHistoryItem[];
  }

  export interface UserSearch {
    userId: number;
    query: string;
    searchCount: number;
  }