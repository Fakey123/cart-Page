export interface ApiResponse {
    message: string;
    status: string;
    data: any; // Use 'any' type since 'data' can be null or any other type in different responses
  }