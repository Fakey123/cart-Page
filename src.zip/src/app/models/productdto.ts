// export interface ProductDTO {
//     productId: number;
//     name: string;
//     newPrice: number;
//     oldPrice: number;
//     gender: string;
//     quantity: number;
//     rating: number;
//     brand: string;
//     popularity: string;
//     color: string;
//     description: string;
//     image1: string;
//     image2: string;
//     image3: string;
//     discount: number;
//     highlightShippingFee: number;
//     categoryName: string;
//   }

import { SafeUrl } from "@angular/platform-browser";

export interface ProductDTO {
    productId: number;
    name: string;
    newPrice: number;
    oldPrice: number;
    gender: string;
    quantity: number;
    rating: number;
    brand: string;
    popularity: string;
    color: string;
    description: string;
    image1?: SafeUrl;
    image2?: SafeUrl;
    image3: string;
    discount: number;
    highlightShippingFee: number;
    categoryName: string;
  }
