export interface Brand {
    brand: string;
}