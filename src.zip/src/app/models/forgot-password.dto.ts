export interface ForgotPasswordDTO {
    email: string;
    otp?: string;
    newpassword?: string;
    confirmpassword?: string;
  }


 