import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // const authToken = localStorage.getItem('token');
    const authToken = sessionStorage.getItem('token');
 
    const modifiedReq = req.clone({
      setHeaders: {
        Authorization: authToken ? `Bearer ${authToken.replace(/"/g, '')}` : ''
      }
    });
 
    return next.handle(modifiedReq);
  }
}