import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { ProductResponseDTO } from '../models/productfilterresponse'; 

@Injectable({
  providedIn: 'root'
})
export class FilterService {

  private baseUrl = 'http://localhost:8765/api/search';

  constructor(private http: HttpClient) { }

  getFilteredProducts(query: string, category?: number, priceMin?: number, priceMax?: number, ratingMin?: number, brand?: string, color?: string, discount?: number, userId?: number, page: number = 0, size: number = 10): Observable<ProductResponseDTO> {
    let params = new HttpParams()
      .set('query', query)
      .set('page', page.toString())
      .set('size', size.toString());

    if (category !== undefined) params = params.set('category', category.toString());
    if (priceMin !== undefined) params = params.set('priceMin', priceMin.toString());
    if (priceMax !== undefined) params = params.set('priceMax', priceMax.toString());
    if (ratingMin !== undefined) params = params.set('ratingMin', ratingMin.toString());
    if (brand !== undefined) params = params.set('brand', brand);
    if (color !== undefined) params = params.set('color', color);
    if (discount !== undefined) params = params.set('discount', discount.toString());
    if (userId !== undefined) params = params.set('userId', userId.toString());

    return this.http.get<ProductResponseDTO>(`${this.baseUrl}/filtered`, { params })
      .pipe(catchError(this.handleError));
  }

  sortResultProducts(query: string, userId?: number, page: number = 0, size: number = 10, sort?: string): Observable<ProductResponseDTO> {
    let params = new HttpParams()
      .set('query', query)
      .set('page', page.toString())
      .set('size', size.toString());

    if (userId !== undefined) params = params.set('userId', userId.toString());
    if (sort !== undefined) params = params.set('sort', sort);

    return this.http.get<ProductResponseDTO>(this.baseUrl, { params })
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    if (error.error instanceof ErrorEvent) {
      console.error("Client Side Error:", error.error.message);
    } else {
      console.error(`Server Responded with a status ${error.status}, the body was: ${error.error}`);
    }
    return throwError(() => new Error("Something went wrong, please try again later."));
  }
}