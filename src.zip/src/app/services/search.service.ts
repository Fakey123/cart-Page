import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { catchError, Observable, throwError } from 'rxjs';
import { SearchSuggestion } from '../models/searchsuggestion';
import { SearchHistoryResponse, UserSearch } from '../models/searchhistoryresponse';
import { ApiResponse } from '../models/apiresponse';
import { ProductResponseDTO } from '../models/productfilterresponse';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http:HttpClient) { }


  getSearchSuggestionsFromProductsPresentAvailable(query: string): Observable<SearchSuggestion> {
    return this.http.get<SearchSuggestion>(`http://localhost:8765/api/search/suggestions/products?query=${query}`)
      .pipe(catchError(this.handleError));
  }

  getUserSearchHistory(userId:number):Observable<SearchHistoryResponse>{
    return this.http.get<SearchHistoryResponse>(`http://localhost:8765/api/search/history?userId=${userId}`)
    .pipe(catchError(this.handleError));
   }


   addUserSearchHistory(userId:number,userSearch: UserSearch): Observable<SearchHistoryResponse> {
    return this.http.post<SearchHistoryResponse>(`http://localhost:8765/api/search/history?userId=${userId}`, userSearch)
      .pipe(catchError(this.handleError));
  }

  deleteUserSearchHistoryBySearchId(userId:number,queryId:number):Observable<ApiResponse>{
    return this.http.delete<ApiResponse>(`http://localhost:8765/api/search/history?userId=${userId}&queryId=${queryId}`)
    .pipe(catchError(this.handleError));
   }


   getSearchResults(query: string): Observable<ProductResponseDTO> {
    return this.http.get<ProductResponseDTO>(`http://localhost:8765/api/search?query=${query}`)
      .pipe(catchError(this.handleError));
  }



  private handleError(error:HttpErrorResponse){
    if(error.error instanceof ErrorEvent){
      console.log("Client Side Error",error.error.message);
    }
    else{
      console.log(`Server Responded with a status ${error.status} the body was ${error.error}` )
    }
    return throwError(()=>"Something went wrong, Please try again later");
  }

  
}
