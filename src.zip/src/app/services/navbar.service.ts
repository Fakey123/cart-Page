import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {

  constructor(private http:HttpClient) { }

  getUserById(id:number):Observable<User>{
   return this.http.get<User>(`http://localhost:8765/api/user/profile/${id}`)
   .pipe(catchError(this.handleError));
  }


  private handleError(error:HttpErrorResponse){
    if(error.error instanceof ErrorEvent){
      console.log("Client Side Error",error.error.message);
    }
    else{
      console.log(`Server Responded with a status ${error.status} the body was ${error.error}` )
    }
    return throwError(()=>"Something went wrong, Please try again later");
  }

}
