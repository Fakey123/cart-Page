import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { User } from '../models/user';
import { Category } from '../models/categorydto';
import { Brand } from '../models/brand.model';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http:HttpClient) { }

  getAllCategories():Observable<Category[]>{
   return this.http.get<Category[]>(`http://localhost:8765/api/products/categories`)
   .pipe(catchError(this.handleError));
  }

  getAllBrands():Observable<Brand[]>{
    return this.http.get<Brand[]>(`http://localhost:8765/api/products/brands`)
    .pipe(catchError(this.handleError));
   }


   getImage(id: number, imageType: string): Observable<Blob> {
    return this.http.get(`http://localhost:8765/api/products/${id}/image/${imageType}`, { responseType: 'blob' });
  }

  private handleError(error:HttpErrorResponse){
    if(error.error instanceof ErrorEvent){
      console.log("Client Side Error",error.error.message);
    }
    else{
      console.log(`Server Responded with a status ${error.status} the body was ${error.error}` )
    }
    return throwError(()=>"Something went wrong, Please try again later");
  }

}
