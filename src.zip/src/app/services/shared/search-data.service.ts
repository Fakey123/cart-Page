import { EventEmitter, Injectable } from '@angular/core';
import { ProductResponseDTO } from '../../models/productfilterresponse';

@Injectable({
  providedIn: 'root'
})
export class SearchDataService {
    private searchResults: ProductResponseDTO = { products: [], pagination: { totalPages: 0, currentPage: 1 } };
    searchResultsChanged = new EventEmitter<ProductResponseDTO>();
  
    setSearchResults(results: ProductResponseDTO) {
      this.searchResults = results;
      this.searchResultsChanged.emit(this.searchResults);
    }
  
    getSearchResults() {
      return this.searchResults;
    }
    
}
