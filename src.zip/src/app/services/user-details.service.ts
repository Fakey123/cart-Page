import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { Address } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  constructor(private http:HttpClient) { }

  getUserAddress(id:number):Observable<Address>{
   return this.http.get<Address>(`http://localhost:8765/api/user/address/user/${id}`)
   .pipe(catchError(this.handleError));
  }

  // getUserAddress(userId:number):Observable<Address>{
  //   return this.http.get<Address>(`http://localhost:8765/api/user/address/user/${userId}`)
  //   .pipe(catchError(this.handleError));
  //  }

  //  http://localhost:8765/api/user/address/user/22

    // getUserById(id:number):Observable<User>{
  //  return this.http.get<User>(`http://localhost:8765/api/user/profile/${id}`)
  //  .pipe(catchError(this.handleError));
  // }



  private handleError(error:HttpErrorResponse){
    if(error.error instanceof ErrorEvent){
      console.log("Client Side Error",error.error.message);
    }
    else{
      console.log(`Server Responded with a status ${error.status} the body was ${error.error}` )
    }
    return throwError(()=>"Something went wrong, Please try again later");
  }
}
