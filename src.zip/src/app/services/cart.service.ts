// cart.service.ts

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, switchMap, of, throwError } from 'rxjs'; // Import switchMap and of
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, tap, catchError } from 'rxjs/operators';
import { CartItem } from '../models/cartdtos';
import { ApiResponse } from '../models/apiresponse';


@Injectable({
    providedIn: 'root',
})
export class CartService {
    private cartItems = new BehaviorSubject<CartItem[]>([]);
    private apiUrl = 'http://localhost:8765/api/cart'; // Cart Microservice API
    private orderApiUrl = 'http://localhost:8765/api/orders'; // **Order Microservice API URL**

    constructor(private http: HttpClient) { }

    getCartItems(userId: number): Observable<CartItem[]> {
    return this.http.get<any>(`${this.apiUrl}/${userId}`).pipe( // Response type is 'any' now for flexibility initially
        map((response: any) => { // Map the entire response
            if (response && response.data && response.data.cart && response.data.cart.length > 0) {
                return response.data.cart[0].cartItems || []; // Navigate to response.data.cart[0].cartItems
            } else {
                return [];
            }
        }),
        tap(items => {
            this.cartItems.next(items);
        })
    );
}

  updateQuantity(userId: number, cartItemId: number, quantity: number): Observable<CartItem> { // Pass userId and cartItemId
    return this.http.put<CartItem>(`${this.apiUrl}/${userId}/cart-items/${cartItemId}`, { quantity }).pipe( // Call PUT endpoint
      tap(updatedItem => {
        const currentItems = this.cartItems.value;
        const updatedItems = currentItems.map(item =>
          item.cartItemId === cartItemId ? { ...item, ...updatedItem } : item // Update item in BehaviorSubject
        );
        this.cartItems.next(updatedItems);
      })
    );
  }

  removeItem(userId: number, cartItemId: number): Observable<any> { // Pass userId and cartItemId
    return this.http.delete(`${this.apiUrl}/${userId}/cart-items/${cartItemId}`).pipe( // Call DELETE endpoint
      tap(() => {
        const currentItems = this.cartItems.value;
        const updatedItems = currentItems.filter(item => item.cartItemId !== cartItemId); // Remove item from BehaviorSubject
        this.cartItems.next(updatedItems);
      })
    );
  }

  emptyCart(userId: number): Observable<any> { // Pass userId
    return this.http.delete(`${this.apiUrl}/${userId}`).pipe( // Call DELETE endpoint to clear cart
      tap(() => {
        this.cartItems.next([]); // Clear BehaviorSubject
      })
    );
  }

  getTotal(): number { // Calculate total from BehaviorSubject value
    return this.cartItems.value.reduce(
      (total, item) => total + (item.productPrice || 0) * item.quantity, // Use optional chaining in case productPrice is undefined
      0
    );
  }


  getCartItemsObservable(): Observable<CartItem[]> { // Expose BehaviorSubject as Observable
    return this.cartItems.asObservable();
  }
    placeOrder(userId: number, cartItems: CartItem[]): Observable<any> { // Returns Observable of any for now, refine later
        if (!cartItems || cartItems.length === 0) {
            console.warn('Cart is empty, cannot place order.');
            return of({ success: false, message: 'Cart is empty.' }); // Return an observable with an error indicator
        }
        return this.http.post(`${this.orderApiUrl}/${userId}/placeOrder`, {}).pipe( // POST to Order Microservice
            tap(() => {
                console.log('Order placed successfully (full cart).');
                this.cartItems.next([]); // Optionally clear cart locally after successful order
            }),
            catchError(error => {
                console.error('Error placing order (full cart):', error);
                return of({ success: false, message: 'Error placing order.' }); // Return observable with error indicator
            })
        );
    }

    // **New function: Place Order by Cart Item ID (Single Item)**
    placeOrderByCartItem(userId: number, cartItemId: number): Observable<any> { // Returns Observable of any for now, refine later
        return this.http.post(`${this.orderApiUrl}/${userId}/cart-items/${cartItemId}/placeOrder`, {}).pipe( // POST to Order Microservice
            tap(() => {
                console.log('Order placed successfully for cart item:', cartItemId);
                // Optionally remove the single item from the cart locally
                const currentItems = this.cartItems.value;
                const updatedItems = currentItems.filter(item => item.cartItemId !== cartItemId);
                this.cartItems.next(updatedItems);
            }),
            catchError(error => {
                console.error('Error placing order for cart item:', cartItemId, error);
                return of({ success: false, message: 'Error placing order for item.' }); // Return observable with error indicator
            })
        );
    }

    addProductToCart(userId:number,cartItemDto:CartItem):Observable<ApiResponse>{
      return this.http.post<ApiResponse>(`${this.apiUrl}/${userId}/cart-items`,cartItemDto)
      .pipe(catchError(this.handleError));
    }

    private handleError(error: HttpErrorResponse) {
      if (error.error instanceof ErrorEvent) {
        console.error("Client side error", error.error.message);
      } else {
        console.error(`Server responded with the status ${error.status}, the body was ${error.error}`);
      }
      return throwError(() => 'Something went wrong, please try again later');
    }

}


