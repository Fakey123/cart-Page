import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { authUser } from '../models/authuser';
import { catchError, Observable, throwError } from 'rxjs';
import { ForgotPasswordDTO } from '../models/forgot-password.dto';
import { ApiResponse } from '../models/apiresponse';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {
  private signUpUrl = 'http://localhost:8765/api/auth/signup';
  private loginUrl = 'http://localhost:8765/api/auth/login';
  private generateOtpUrl = 'http://localhost:8765/api/auth/generate-otp';
  private verifyOtpUrl = 'http://localhost:8765/api/auth/verify-otp';
  private resetPasswordUrl = 'http://localhost:8765/api/auth/reset-password-with-otp';
  private currentUserIdUrl = 'http://localhost:8765/api/auth/current-id';
  private logoutUrl = 'http://localhost:8765/api/auth/logout';

  constructor(private http: HttpClient) { }

  signUp(user: authUser): Observable<authUser> {
    return this.http.post<authUser>(this.signUpUrl, user)
      .pipe(catchError(this.handleError));
  }

  login(user: authUser): Observable<any> {
    return this.http.post<any>(this.loginUrl, user)
      .pipe(catchError(this.handleError));
  }

  generateOtp(dto: ForgotPasswordDTO): Observable<any> {
    return this.http.post<any>(this.generateOtpUrl, dto)
      .pipe(catchError(this.handleError));
  }

  verifyOtp(dto: ForgotPasswordDTO): Observable<any> {
    return this.http.post<any>(this.verifyOtpUrl, dto)
      .pipe(catchError(this.handleError));
  }

  resetPassword(dto: ForgotPasswordDTO): Observable<any> {
    return this.http.post<any>(this.resetPasswordUrl, dto)
      .pipe(catchError(this.handleError));
  }

  logoutUser(): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.logoutUrl,{},{
      headers:{
        'Content-Type':'application/json'
      }
    }).pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error("Client side error", error.error.message);
    } else {
      console.error(`Server responded with the status ${error.status}, the body was ${error.error}`);
    }
    return throwError(() => 'Something went wrong, please try again later');
  }
}