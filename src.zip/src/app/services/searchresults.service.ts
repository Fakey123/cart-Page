import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { ProductResponseDTO } from '../models/productfilterresponse';

@Injectable({
  providedIn: 'root'
})
export class SearchresultsService {

  constructor(private http:HttpClient) { }





    private handleError(error:HttpErrorResponse){
      if(error.error instanceof ErrorEvent){
        console.log("Client Side Error",error.error.message);
      }
      else{
        console.log(`Server Responded with a status ${error.status} the body was ${error.error}` )
      }
      return throwError(()=>"Something went wrong, Please try again later");
    }
}
