import { TestBed } from '@angular/core/testing';

import { SearchresultsService } from './searchresults.service';

describe('SearchresultsService', () => {
  let service: SearchresultsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchresultsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
